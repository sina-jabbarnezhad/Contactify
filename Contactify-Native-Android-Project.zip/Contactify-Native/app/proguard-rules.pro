# Contactify release rules
