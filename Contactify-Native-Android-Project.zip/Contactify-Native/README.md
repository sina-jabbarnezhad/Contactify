# Contactify — Native Android

This is a real Kotlin + Jetpack Compose Android project converted from the uploaded `Contactify.html`.

## Important

This project does **not** use WebView, HTML, CSS, or JavaScript at runtime.

The UI, country picker, inputs, animations, validation flow, preview, and VCF export are implemented natively in Kotlin/Compose.

## Open and build

1. Install Android Studio.
2. Open this `Contactify` folder.
3. Let Gradle sync.
4. Connect an Android phone or create an emulator.
5. Press **Run** to install the app.
6. For an APK: **Build → Generate App Bundles or APKs → Generate APKs**.

The country dataset was extracted from the uploaded HTML and contains 104 country entries.

## VCF export

Export uses Android's native `ACTION_CREATE_DOCUMENT` flow, so the user chooses where to save the `.vcf` file.

Generation is streamed directly to the selected file instead of building the entire VCF in RAM.
